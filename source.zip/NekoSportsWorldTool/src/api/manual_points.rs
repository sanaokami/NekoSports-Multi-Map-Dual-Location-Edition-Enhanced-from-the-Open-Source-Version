//! Explicit, school-scoped local points. Never stored as server point-cache data.

use crate::location::Coordinate;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

#[derive(Debug, Clone, Copy, Default, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CoordinateSystem {
    #[default]
    Gcj02,
    Bd09,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct Settings {
    pub enabled: bool,
    pub school_unid: String,
    pub coordinate_system: CoordinateSystem,
    // Legacy points are route coordinates only; never infer check-in locations.
    #[serde(alias = "points")]
    pub route_points: Vec<Coordinate>,
    pub checkin_points: Vec<Coordinate>,
}

impl Settings {
    pub fn from_text(
        route: &str,
        checkin: &str,
        system: CoordinateSystem,
        school: &str,
    ) -> Result<Self, String> {
        let settings = Self {
            enabled: true,
            school_unid: school.to_owned(),
            coordinate_system: system,
            route_points: parse_points(route, "定位点", 3, 100)?,
            checkin_points: parse_points(checkin, "打卡点", 1, 30)?,
        };
        settings.validate_for(school)?;
        Ok(settings)
    }

    pub fn text(&self) -> String {
        format_points(&self.route_points)
    }
    pub fn checkin_text(&self) -> String {
        format_points(&self.checkin_points)
    }

    pub fn validate_for(&self, school: &str) -> Result<(), String> {
        if school.trim().is_empty() || school != self.school_unid {
            return Err("手动点位属于其他学校，请为当前学校重新保存或切回服务器点位".into());
        }
        validate_points(&self.route_points, "定位点", 3, 100)?;
        validate_points(&self.checkin_points, "打卡点", 1, 30)?;
        for point in self.route_points.iter().chain(&self.checkin_points) {
            let (a, o) = self.bd(point);
            Coordinate::new(a, o, 0.0)?;
            let (a, o) = self.gcj(point);
            Coordinate::new(a, o, 0.0)?;
        }
        Ok(())
    }

    /// Route coordinates retain the order entered by the user (BD-09).
    pub fn route_bd(&self, school: &str) -> Result<Vec<(f64, f64)>, String> {
        self.validate_for(school)?;
        Ok(self.route_points.iter().map(|p| self.bd(p)).collect())
    }

    fn bd(&self, point: &Coordinate) -> (f64, f64) {
        match self.coordinate_system {
            CoordinateSystem::Gcj02 => {
                crate::track::geom::gcj02_to_bd09(point.latitude, point.longitude)
            }
            CoordinateSystem::Bd09 => (point.latitude, point.longitude),
        }
    }

    fn gcj(&self, point: &Coordinate) -> (f64, f64) {
        match self.coordinate_system {
            CoordinateSystem::Gcj02 => (point.latitude, point.longitude),
            CoordinateSystem::Bd09 => {
                crate::track::wire::bd09_to_gcj02(point.latitude, point.longitude)
            }
        }
    }

    pub fn anchor(&self, school: &str) -> Result<Coordinate, String> {
        self.validate_for(school)?;
        let (a, o) = self.gcj(&self.route_points[0]);
        Coordinate::new(a, o, 0.0)
    }

    pub fn payload(&self, school: &str) -> Result<Vec<Value>, String> {
        self.validate_for(school)?;
        Ok(self
            .checkin_points
            .iter()
            .enumerate()
            .map(|(i, p)| {
                let (lat, lon) = self.bd(p);
                let (glat, glon) = self.gcj(p);
                json!({
                    "lat": lat, "lon": lon, "glat": glat, "glon": glon,
                    "pointName": format!("手动打卡点 {}", i + 1),
                    "isFixed": 0, "isMustPoint": false,
                })
            })
            .collect())
    }
}

fn format_points(points: &[Coordinate]) -> String {
    points
        .iter()
        .map(|p| format!("{:.7},{:.7}", p.latitude, p.longitude))
        .collect::<Vec<_>>()
        .join("\n")
}

fn parse_points(
    text: &str,
    label: &str,
    min: usize,
    max: usize,
) -> Result<Vec<Coordinate>, String> {
    let mut points = Vec::new();
    for (index, line) in text.lines().enumerate() {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        let fields: Vec<_> = line
            .split(|c: char| c == ',' || c == '，' || c.is_whitespace())
            .filter(|s| !s.is_empty())
            .collect();
        let parse = || -> Result<Coordinate, String> {
            if fields.len() != 2 {
                return Err("每行填写两个数字：纬度,经度".into());
            }
            Coordinate::new(
                fields[0].parse().map_err(|_| "纬度不是数字")?,
                fields[1].parse().map_err(|_| "经度不是数字")?,
                0.0,
            )
        };
        points.push(parse().map_err(|e| format!("{label}第 {} 行：{e}", index + 1))?);
        if points.len() > max {
            return Err(format!("{label}最多 {max} 个"));
        }
    }
    validate_points(&points, label, min, max)?;
    Ok(points)
}

fn validate_points(
    points: &[Coordinate],
    label: &str,
    min: usize,
    max: usize,
) -> Result<(), String> {
    if !(min..=max).contains(&points.len()) {
        return Err(format!(
            "请单独设置 {min} 至 {max} 个{label}；旧版点位仅保留为定位点，请补填打卡点后保存"
        ));
    }
    for (i, point) in points.iter().enumerate() {
        point
            .validate()
            .map_err(|e| format!("{label} {}：{e}", i + 1))?;
        if point.latitude == 0.0 && point.longitude == 0.0 {
            return Err(format!("{label} {} 不能为 0,0", i + 1));
        }
        if points[..i].iter().any(|p| p.is_near(*point, 1e-6)) {
            return Err(format!("{label} {} 与前面重复", i + 1));
        }
    }
    Ok(())
}

/// Manual mode uses its first point as the request anchor without changing device identity.
pub fn effective_anchor(
    identity: &super::model::HeaderIdentity,
    school: &str,
    settings: &Settings,
) -> Result<Coordinate, String> {
    if settings.enabled {
        settings.anchor(school)
    } else {
        identity.anchor_coordinate()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn settings() -> Settings {
        Settings::from_text(
            "39.9000,116.4000\n39.9010，116.4010\n39.9000 116.4020",
            "39.9005,116.4010",
            CoordinateSystem::Gcj02,
            "school-a",
        )
        .unwrap()
    }

    #[test]
    fn coordinates_round_trip_and_local_points_have_no_server_ids() {
        let s = settings();
        let payload = s.payload("school-a").unwrap();
        for (point, original) in payload.iter().zip(&s.checkin_points) {
            let bd = super::super::fence::point_xy(point).unwrap();
            let gcj = crate::track::wire::bd09_to_gcj02(bd.0, bd.1);
            assert!((gcj.0 - original.latitude).abs() < 1e-6);
            assert!((gcj.1 - original.longitude).abs() < 1e-6);
            assert!(point.get("id").is_none());
        }
        let saved = serde_json::to_string(&s).unwrap();
        let restored: Settings = serde_json::from_str(&saved).unwrap();
        assert_eq!(restored.payload("school-a").unwrap(), payload);
        assert!(restored.payload("school-b").is_err());
        assert_eq!(restored.anchor("school-a").unwrap(), s.route_points[0]);
        let bd = Settings {
            coordinate_system: CoordinateSystem::Bd09,
            route_points: s
                .route_bd("school-a")
                .unwrap()
                .into_iter()
                .map(|p| Coordinate::new(p.0, p.1, 0.).unwrap())
                .collect(),
            checkin_points: payload
                .iter()
                .map(|v| {
                    Coordinate::new(v["lat"].as_f64().unwrap(), v["lon"].as_f64().unwrap(), 0.0)
                        .unwrap()
                })
                .collect(),
            ..s.clone()
        };
        assert!(bd
            .anchor("school-a")
            .unwrap()
            .is_near(s.route_points[0], 1e-6));
        let converted = bd.payload("school-a").unwrap();
        for (actual, expected) in converted.iter().zip(&payload) {
            for field in ["lat", "lon", "glat", "glon"] {
                assert!(
                    (actual[field].as_f64().unwrap() - expected[field].as_f64().unwrap()).abs()
                        < 1e-6
                );
            }
        }
    }

    #[test]
    fn rejects_empty_invalid_duplicate_and_oversized_input() {
        for text in [
            "",
            "39.9,116.4",
            "39.9,116.4\n39.9,116.4\n39.91,116.41",
            "NaN,116.4\n39.91,116.41\n39.92,116.42",
            "91,116.4\n39.91,116.41\n39.92,116.42",
            "39.9,181\n39.91,116.41\n39.92,116.42",
            "39.9,116.4,1",
            "0,0\n39.91,116.41\n39.92,116.42",
        ] {
            assert!(
                Settings::from_text(
                    text,
                    "39.9005,116.4010",
                    CoordinateSystem::Gcj02,
                    "school-a"
                )
                .is_err(),
                "{text}"
            );
        }
        assert!(Settings::from_text(
            &"39.9,116.4\n".repeat(101),
            "39.9005,116.4010",
            CoordinateSystem::Gcj02,
            "school-a"
        )
        .is_err());
    }

    #[test]
    fn legacy_config_never_invents_checkin_points() {
        let original = settings();
        let old =
            json!({"enabled": true, "school_unid": "school-a", "points": original.route_points});
        let restored: Settings = serde_json::from_value(old).unwrap();
        assert_eq!(restored.route_points, original.route_points);
        assert!(restored.checkin_points.is_empty());
        assert!(restored
            .validate_for("school-a")
            .unwrap_err()
            .contains("打卡点"));
        let new = serde_json::to_value(&original).unwrap();
        assert!(new.get("points").is_none());
        assert_eq!(new["route_points"].as_array().unwrap().len(), 3);
        assert_eq!(new["checkin_points"].as_array().unwrap().len(), 1);
    }

    #[test]
    fn moving_checkins_does_not_change_route_and_payload_reports_actual_passes() {
        let s = settings();
        let mut client = super::super::client::ApiClient::new(
            Default::default(),
            Some(super::super::model::Session {
                unid: "school-a".into(),
                ..Default::default()
            }),
        );
        client.set_test_host("http://127.0.0.1:1".into());
        let anchor = s.anchor("school-a").unwrap();
        let load = |client: &mut super::super::client::ApiClient, settings: &Settings| {
            super::super::points::fetch_run_data(
                client,
                anchor,
                None,
                &[(20., 100.)],
                settings,
                &mut |_| {},
            )
            .unwrap()
        };
        let initial = load(&mut client, &s);
        assert_eq!(initial.route_points, s.route_bd("school-a").unwrap());
        let track = crate::track::generator::build(
            1200.,
            600,
            7,
            (anchor.latitude, anchor.longitude),
            1_700_000_000_000,
            &initial.route_points,
        );
        let sample = track.locations.iter().find(|p| p.ptype != -1).unwrap();
        let mut changed = s.clone();
        changed.coordinate_system = CoordinateSystem::Bd09;
        changed.route_points = initial
            .route_points
            .iter()
            .map(|p| Coordinate::new(p.0, p.1, 0.).unwrap())
            .collect();
        changed.checkin_points = vec![
            Coordinate::new(sample.gLat, sample.gLng, 0.).unwrap(),
            Coordinate::new(30., 110., 0.).unwrap(),
        ];
        let result = load(&mut client, &changed);
        assert_eq!(initial.route_points, result.route_points);
        let wrapper = crate::track::wire::five_point_wrapper(
            &result.checkin_points,
            &track,
            &Default::default(),
        );
        crate::track::wire::validate_five_point_wrapper(&wrapper).unwrap();
        let outer: Value = serde_json::from_str(&wrapper).unwrap();
        let checks: Vec<Value> =
            serde_json::from_str(outer["fivePointJson"].as_str().unwrap()).unwrap();
        assert_eq!(checks.len(), 2);
        assert_eq!(checks[0]["isPass"], true);
        assert_eq!(checks[1]["isPass"], false);
    }

    #[test]
    fn checkins_have_independent_validation_and_may_overlap_route_points() {
        let route = settings().text();
        for checkins in [
            "".to_owned(),
            "NaN,116.4".into(),
            "39.9,116.4\n39.9,116.4".into(),
            (0..31)
                .map(|i| format!("39.{:05},116.4", 90000 + i * 10))
                .collect::<Vec<_>>()
                .join("\n"),
        ] {
            assert!(
                Settings::from_text(&route, &checkins, CoordinateSystem::Gcj02, "school-a")
                    .is_err()
            );
        }
        assert!(Settings::from_text(
            &route,
            "39.9000,116.4000",
            CoordinateSystem::Gcj02,
            "school-a"
        )
        .is_ok());
    }

    #[test]
    fn manual_selection_avoids_the_server_and_preserves_server_cache() {
        let dir = std::env::temp_dir().join(format!("manual-points-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir).unwrap();
        crate::platform::TEST_DATA_DIR.with(|p| *p.borrow_mut() = Some(dir.clone()));
        let mut config = super::super::model::Config::default();
        config.manual_points = settings();
        super::super::model::save_config(&config).unwrap();
        std::fs::write(dir.join("points_cache.json"), "server-cache-sentinel").unwrap();
        let session = super::super::model::Session {
            uid: 7,
            unid: "school-a".into(),
            token: "fixture".into(),
            ..Default::default()
        };
        let mut client = super::super::client::ApiClient::new(Default::default(), Some(session));
        // Any attempted HTTP request would fail, so success verifies manual selection precedes HTTP/cache.
        client.set_test_host("http://127.0.0.1:1".into());
        let mut logs = Vec::new();
        let anchor = effective_anchor(&client.identity, "school-a", &config.manual_points).unwrap();
        let points = super::super::points::fetch_points(&mut client, anchor, &mut |s| {
            logs.push(s.to_owned())
        })
        .unwrap();
        assert_eq!(points.len(), 1);
        assert!(logs.iter().any(|s| s.contains("手动点位")));
        let route = config.manual_points.route_bd("school-a").unwrap();
        let track = crate::track::generator::build(
            1200.0,
            600,
            7,
            (anchor.latitude, anchor.longitude),
            1_700_000_000_000,
            &route,
        );
        track.validate_consistency().unwrap();
        let wrapper = crate::track::wire::five_point_wrapper(&points, &track, &Default::default());
        crate::track::wire::validate_five_point_wrapper(&wrapper).unwrap();
        assert_eq!(
            std::fs::read_to_string(dir.join("points_cache.json")).unwrap(),
            "server-cache-sentinel"
        );
        client.login.as_mut().unwrap().unid = "school-b".into();
        assert!(super::super::points::fetch_points(&mut client, anchor, &mut |_| {}).is_err());
        config.manual_points.enabled = false;
        super::super::model::save_config(&config).unwrap();
        client.login.as_mut().unwrap().unid = "school-a".into();
        assert!(super::super::points::fetch_points(&mut client, anchor, &mut |_| {}).is_err());
        crate::platform::TEST_DATA_DIR.with(|p| *p.borrow_mut() = None);
        std::fs::remove_dir_all(dir).unwrap();
    }
}
